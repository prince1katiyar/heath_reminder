def get_water_facts():
    """
    gets Random Water facts
    """
    water_facts = [
        "Even mild dehydration can reduce physical performance",
        "Drink more water","Keep calm and drink water",
        "Water Can Help Control Calories",
        "Health experts commonly recommend eight 8-ounce glasses, which equals about 2 liters, or half a gallon a day."
        ]
    return water_facts
    
def get_exercise_facts():
    """
    gets Random Exercise facts
    """
    workout_facts = [
        "Exercising improves brain performance",
        "Working out sharpens your memory",
        "Exercise builds muscle and gives you good shape",
        " Exercise prevents obesity and prevents signs of ageing"
    ]
    return workout_facts

def get_eye_facts():
    """
    Gets Random eye facts 
    """
    relax_eye_facts = [
        "Taking a break from the screen will help you bring balance to your digital and real-world lives",
        "Stepping away from technology not only gives your brain a break but also gives you the added bonus of perspective.",
        "it is suggested that frequent breaks like 5-10 minutes for every 60 minutes is good for eyes",
        "Eye strain from hours of screen time can result in eye irritation, dryness, fatigue or blurred vision, and such problems are increasingly common, according to a new report."
    ]
    return relax_eye_facts